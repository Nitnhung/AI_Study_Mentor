"""
providers/gemini_provider.py — Google Gemini (đề bài gợi ý dùng Google Gemini).

Dùng REST API qua urllib (thư viện chuẩn của Python) thay vì SDK:
- Không phụ thuộc phiên bản SDK (SDK đổi API liên tục, REST ổn định hơn).
- Đổi model chỉ cần đổi biến môi trường GEMINI_MODEL.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request

from ...config import settings
from ..models import ProviderResult
from .base import AIProvider, ProviderError

_API_BASE = "https://generativelanguage.googleapis.com/v1beta/models"


class GeminiProvider(AIProvider):
    name = "gemini"

    def __init__(self, api_key: str | None = None, model: str | None = None):
        self.api_key = api_key or settings.gemini_api_key
        self.model = model or settings.gemini_model
        self.vision_model = settings.gemini_vision_model

    def is_configured(self) -> bool:
        return bool(self.api_key)

    # ── nội bộ ──────────────────────────────────────────────────────
    def _call(self, model: str, payload: dict) -> ProviderResult:
        url = f"{_API_BASE}/{model}:generateContent?key={self.api_key}"
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=settings.request_timeout_seconds) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")[:500]
            # 429/5xx: đáng retry; 400/401/403: lỗi cấu hình, không retry
            retryable = e.code in (408, 429, 500, 502, 503, 504)
            raise ProviderError(self.name, f"HTTP {e.code}: {body}", retryable=retryable)
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise ProviderError(self.name, f"Network error: {e}", retryable=True)

        try:
            text = data["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError, TypeError):
            # Có thể bị safety filter chặn hoặc response rỗng
            raise ProviderError(self.name, f"Unexpected response shape: {str(data)[:300]}", retryable=False)

        usage = data.get("usageMetadata", {})
        tokens = int(usage.get("totalTokenCount", 0))
        return ProviderResult(text=text, model_version=model, tokens_used=tokens, raw=data)

    @staticmethod
    def _gen_config(max_output_tokens: int, temperature: float) -> dict:
        return {"maxOutputTokens": max_output_tokens, "temperature": temperature}

    # ── API công khai ───────────────────────────────────────────────
    def generate(self, system_prompt, user_prompt, max_output_tokens=1500, temperature=0.4) -> ProviderResult:
        payload = {
            "systemInstruction": {"parts": [{"text": system_prompt}]},
            "contents": [{"role": "user", "parts": [{"text": user_prompt}]}],
            "generationConfig": self._gen_config(max_output_tokens, temperature),
        }
        return self._call(self.model, payload)

    def generate_with_image(self, system_prompt, user_prompt, image_base64,
                            image_mime_type="image/jpeg", max_output_tokens=1500,
                            temperature=0.4) -> ProviderResult:
        payload = {
            "systemInstruction": {"parts": [{"text": system_prompt}]},
            "contents": [{
                "role": "user",
                "parts": [
                    {"inlineData": {"mimeType": image_mime_type, "data": image_base64}},
                    {"text": user_prompt},
                ],
            }],
            "generationConfig": self._gen_config(max_output_tokens, temperature),
        }
        return self._call(self.vision_model, payload)
