import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/services/api_service.dart';
import '../pages/ai_answer_page.dart';

class AskAiPanel extends StatefulWidget {
  const AskAiPanel({super.key});
  @override
  State<AskAiPanel> createState() => _AskAiPanelState();
}

class _AskAiPanelState extends State<AskAiPanel> {
  final _controller = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  Future<void> _sendQuestion() async {
    final q = _controller.text.trim();
    if (q.isEmpty) return;
    setState(() => _isLoading = true);
    try {
      final result = await ApiService.askAI(q);
      if (mounted && result['success'] == true) {
        _controller.clear();
        Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => AiAnswerPage(answer: result['data'])));
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result['message'] ?? 'Lỗi')));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi kết nối: $e')));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.softBorder)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('Hỏi AI ngay bây giờ',
          style: TextStyle(color: AppColors.text, fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        TextField(controller: _controller, minLines: 3, maxLines: 5,
          decoration: InputDecoration(
            hintText: 'Nhập câu hỏi... Ví dụ: JWT là gì?',
            hintStyle: const TextStyle(color: AppColors.muted),
            filled: true, fillColor: const Color(0xFFF8FAFC),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppColors.softBorder)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppColors.primary, width: 1.2)))),
        const SizedBox(height: 12),
        Row(children: [
          const Spacer(),
          _isLoading
            ? const SizedBox(width: 40, height: 40, child: CircularProgressIndicator(strokeWidth: 2))
            : FilledButton.icon(onPressed: _sendQuestion,
                icon: const Icon(Icons.send), label: const Text('Gửi'),
                style: FilledButton.styleFrom(backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white, shape: const StadiumBorder())),
        ]),
      ]),
    );
  }
}
