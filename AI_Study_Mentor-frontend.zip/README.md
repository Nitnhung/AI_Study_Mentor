AI Study Mentor
