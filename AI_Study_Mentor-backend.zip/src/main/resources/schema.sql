-- ══════════════════════════════════════════════════════════
-- AI STUDY MENTOR — DATABASE (MySQL / XAMPP)
-- Chạy file này trong phpMyAdmin hoặc MySQL Workbench
-- TRƯỚC KHI chạy backend Spring Boot
-- ══════════════════════════════════════════════════════════

DROP DATABASE IF EXISTS mentor_db;
CREATE DATABASE mentor_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mentor_db;

-- ═══════════════════════════════════════════
-- BẢNG
-- ═══════════════════════════════════════════

CREATE TABLE users (
    user_id CHAR(36) PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    education_level VARCHAR(50) DEFAULT 'high_school',
    preferred_style VARCHAR(50) DEFAULT 'step_by_step',
    subscription_plan VARCHAR(50) DEFAULT 'free',
    xp_points INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE subjects (
    subject_id CHAR(36) PRIMARY KEY,
    subject_name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT
) ENGINE=InnoDB;

CREATE TABLE questions (
    question_id CHAR(36) PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    subject_id CHAR(36),
    question_text TEXT NOT NULL,
    image_url VARCHAR(255),
    extracted_text_from_image TEXT,
    question_hash VARCHAR(255),
    status VARCHAR(20) DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE SET NULL,
    INDEX idx_question_hash (question_hash),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB;

CREATE TABLE ai_answers (
    answer_id CHAR(36) PRIMARY KEY,
    question_id CHAR(36) NOT NULL UNIQUE,
    content_data JSON NOT NULL,
    is_cached_response TINYINT(1) DEFAULT 0,
    api_tokens_used INT DEFAULT 0,
    ai_model_version VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (question_id) REFERENCES questions(question_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE bookmarks (
    bookmark_id CHAR(36) PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    question_id CHAR(36) NOT NULL,
    folder_name VARCHAR(100) DEFAULT 'Mặc định',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(question_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE quizzes (
    quiz_id CHAR(36) PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    subject_id CHAR(36),
    base_question_id CHAR(36),
    score_percentage DECIMAL(5,2),
    completed_at TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE SET NULL,
    FOREIGN KEY (base_question_id) REFERENCES questions(question_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE quiz_questions (
    qq_id CHAR(36) PRIMARY KEY,
    quiz_id CHAR(36) NOT NULL,
    question_type VARCHAR(50),
    question_payload JSON NOT NULL,
    user_answer TEXT,
    is_correct TINYINT(1),
    instant_feedback TEXT,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(quiz_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE activity_logs (
    log_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    activity_type VARCHAR(50),
    time_spent_seconds INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE user_achievements (
    user_id CHAR(36) NOT NULL,
    badge_id INT NOT NULL,
    unlocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, badge_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE notifications (
    notification_id CHAR(36) PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50),
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE leaderboard (
    leaderboard_id CHAR(36) PRIMARY KEY,
    user_id CHAR(36) NOT NULL UNIQUE,
    ranking INT,
    total_xp_points INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ═══════════════════════════════════════════
-- DỮ LIỆU MẪU (Thầy mở DB phải thấy dữ liệu)
-- ═══════════════════════════════════════════

-- Môn học
INSERT INTO subjects VALUES
('s-math', 'Toán', 'Toán học từ cơ bản đến nâng cao'),
('s-eng',  'Tiếng Anh', 'Ngữ pháp, từ vựng, kỹ năng nghe nói đọc viết'),
('s-phys', 'Vật Lý', 'Cơ học, nhiệt học, điện từ, quang học'),
('s-chem', 'Hoá Học', 'Hoá vô cơ, hoá hữu cơ'),
('s-it',   'CNTT', 'Lập trình, mạng máy tính, cơ sở dữ liệu'),
('s-hist', 'Lịch Sử', 'Lịch sử Việt Nam và thế giới');

-- Users (password: 123456 → BCrypt hash)
INSERT INTO users (user_id, email, password_hash, education_level, preferred_style, subscription_plan, xp_points) VALUES
('u-demo',  'admin@gmail.com',   '$2a$10$xQHp3wMy8k5FVjSg4VV0qeX7xPCGq.qKzF5hVv9cNtPKHYz6GxAHm', 'high_school', 'step_by_step', 'free', 1250),
('u-user2', 'student@gmail.com', '$2a$10$xQHp3wMy8k5FVjSg4VV0qeX7xPCGq.qKzF5hVv9cNtPKHYz6GxAHm', 'university',  'detailed',     'free', 800),
('u-user3', 'hocsinh@gmail.com', '$2a$10$xQHp3wMy8k5FVjSg4VV0qeX7xPCGq.qKzF5hVv9cNtPKHYz6GxAHm', 'middle_school','short',       'free', 450);

-- Câu hỏi mẫu (thầy mở bảng Questions thấy có dữ liệu)
INSERT INTO questions (question_id, user_id, subject_id, question_text, question_hash, status) VALUES
('q-001', 'u-demo',  's-math', 'Giải phương trình x² - 4 = 0',           'hash001', 'Resolved'),
('q-002', 'u-demo',  's-phys', 'Định luật Newton thứ 2 là gì?',          'hash002', 'Resolved'),
('q-003', 'u-demo',  's-it',   'JWT Authentication hoạt động như thế nào?','hash003', 'Resolved'),
('q-004', 'u-user2', 's-eng',  'Simple Past Tense dùng khi nào?',         'hash004', 'Resolved'),
('q-005', 'u-user2', 's-chem', 'Phản ứng oxi hoá khử là gì?',            'hash005', 'Resolved'),
('q-006', 'u-user3', 's-math', 'Cách tính diện tích hình tròn?',          'hash006', 'Resolved');

-- AI Answers mẫu (thầy mở bảng AI_Answers thấy JSON)
INSERT INTO ai_answers (answer_id, question_id, content_data, is_cached_response, api_tokens_used, ai_model_version) VALUES
('a-001', 'q-001', '{"subject":"mathematics","difficulty":"basic","direct_answer":"x = 2 hoặc x = -2","explanation":"Phương trình x² - 4 = 0 là dạng hiệu hai bình phương.","steps":["Chuyển vế: x² = 4","Lấy căn: x = ±√4","Kết luận: x = ±2"],"formulas_or_concepts":["a² - b² = (a-b)(a+b)"],"simplified_explanation":"Tìm số nào nhân với chính nó ra 4.","alternative_approaches":["Phân tích: (x-2)(x+2) = 0"],"key_concepts_summary":["Phương trình bậc hai","Căn bậc hai có 2 giá trị"],"common_mistakes":["Quên nghiệm âm x = -2"],"follow_up_questions":["Giải x² - 9 = 0?","x² + 4 = 0 có nghiệm thực không?"]}', 0, 185, 'gemini-2.0-flash'),
('a-002', 'q-002', '{"subject":"science","difficulty":"basic","direct_answer":"F = m × a","explanation":"Định luật Newton thứ 2: Gia tốc của một vật tỉ lệ thuận với lực tác dụng và tỉ lệ nghịch với khối lượng.","steps":["F là lực (Newton)","m là khối lượng (kg)","a là gia tốc (m/s²)"],"formulas_or_concepts":["F = ma"],"simplified_explanation":"Đẩy mạnh hơn → nhanh hơn. Nặng hơn → chậm hơn.","alternative_approaches":[],"key_concepts_summary":["Lực, khối lượng, gia tốc"],"common_mistakes":["Nhầm đơn vị kg với g"],"follow_up_questions":["Tính gia tốc khi F=10N, m=2kg?"]}', 0, 160, 'gemini-2.0-flash'),
('a-003', 'q-003', '{"subject":"programming","difficulty":"intermediate","direct_answer":"JWT là chuỗi token mã hoá dùng để xác thực người dùng giữa client và server.","explanation":"JSON Web Token gồm 3 phần: Header, Payload, Signature. Server tạo token khi login, client gửi kèm mỗi request.","steps":["User gửi email/password","Server kiểm tra, tạo JWT token","Client lưu token, gửi kèm header Authorization","Server xác thực token mỗi request"],"formulas_or_concepts":["JWT = Base64(Header).Base64(Payload).Signature"],"simplified_explanation":"Giống vé xe buýt — mua 1 lần, đi nhiều chuyến.","alternative_approaches":["Session-based auth","OAuth2"],"key_concepts_summary":["Stateless authentication","Token-based"],"common_mistakes":["Lưu token trong localStorage không an toàn"],"follow_up_questions":["Refresh token dùng để làm gì?"]}', 0, 220, 'gemini-2.0-flash'),
('a-004', 'q-004', '{"subject":"languages","difficulty":"basic","direct_answer":"Simple Past Tense dùng cho hành động đã xảy ra và kết thúc trong quá khứ.","explanation":"Công thức: S + V-ed/V2 + O. Dấu hiệu: yesterday, last week, ago, in 2020.","steps":["Xác định hành động đã xong trong quá khứ","Chia động từ: thêm -ed (regular) hoặc V2 (irregular)","Phủ định: did not + V-inf","Nghi vấn: Did + S + V-inf?"],"formulas_or_concepts":["S + V-ed/V2 + O"],"simplified_explanation":"Kể chuyện đã xảy ra → dùng quá khứ đơn.","alternative_approaches":[],"key_concepts_summary":["Regular vs Irregular verbs","Dấu hiệu nhận biết"],"common_mistakes":["Quên đổi sang V2 với irregular verbs","Dùng did + V-ed (sai: did went → did go)"],"follow_up_questions":["Past Continuous khác gì Past Simple?"]}', 0, 175, 'gemini-2.0-flash'),
('a-005', 'q-005', '{"subject":"science","difficulty":"intermediate","direct_answer":"Phản ứng oxi hoá khử là phản ứng có sự chuyển electron giữa các chất.","explanation":"Chất nhường electron bị oxi hoá, chất nhận electron bị khử. Luôn xảy ra đồng thời.","steps":["Xác định số oxi hoá các nguyên tố","Tìm chất oxi hoá (nhận e⁻) và chất khử (nhường e⁻)","Cân bằng electron","Cân bằng phương trình"],"formulas_or_concepts":["Oxi hoá: nhường e⁻, số oxi hoá tăng","Khử: nhận e⁻, số oxi hoá giảm"],"simplified_explanation":"Một chất cho electron, chất kia nhận — giống trao đổi tiền.","alternative_approaches":[],"key_concepts_summary":["Số oxi hoá","Cân bằng electron"],"common_mistakes":["Nhầm oxi hoá và khử"],"follow_up_questions":["Cân bằng: Fe + HCl → FeCl2 + H2?"]}', 0, 190, 'gemini-2.0-flash'),
('a-006', 'q-006', '{"subject":"mathematics","difficulty":"basic","direct_answer":"S = π × r²","explanation":"Diện tích hình tròn bằng pi nhân bình phương bán kính.","steps":["Xác định bán kính r","Tính r²","Nhân với π ≈ 3.14159"],"formulas_or_concepts":["S = πr²","π ≈ 3.14159"],"simplified_explanation":"Lấy bán kính nhân với chính nó, rồi nhân 3.14.","alternative_approaches":["S = πd²/4 (dùng đường kính)"],"key_concepts_summary":["Bán kính vs đường kính","Số pi"],"common_mistakes":["Nhầm bán kính với đường kính"],"follow_up_questions":["Chu vi hình tròn tính như nào?"]}', 0, 130, 'gemini-2.0-flash');

-- Activity logs mẫu
INSERT INTO activity_logs (user_id, activity_type, time_spent_seconds) VALUES
('u-demo', 'Asked_Question', 30),
('u-demo', 'Asked_Question', 45),
('u-demo', 'Asked_Question', 20),
('u-demo', 'Completed_Quiz', 180),
('u-user2', 'Asked_Question', 60),
('u-user2', 'Asked_Question', 35),
('u-user3', 'Asked_Question', 25);

-- Bookmarks mẫu
INSERT INTO bookmarks (bookmark_id, user_id, question_id, folder_name) VALUES
('bm-001', 'u-demo', 'q-001', 'Toán'),
('bm-002', 'u-demo', 'q-003', 'CNTT');

-- Notifications mẫu
INSERT INTO notifications (notification_id, user_id, message, type) VALUES
('n-1', 'u-demo',  'Chào mừng đến AI Study Mentor!', 'Motivation'),
('n-2', 'u-demo',  'Bạn đạt 1000 XP — tiếp tục phát huy!', 'Motivation'),
('n-3', 'u-demo',  'Quiz Toán mới đã sẵn sàng', 'Alert'),
('n-4', 'u-demo',  'Bạn chưa học hôm nay', 'Reminder'),
('n-5', 'u-user2', 'Chào mừng đến AI Study Mentor!', 'Motivation'),
('n-6', 'u-user3', 'Chào mừng đến AI Study Mentor!', 'Motivation');

-- Leaderboard
INSERT INTO leaderboard (leaderboard_id, user_id, ranking, total_xp_points) VALUES
('lb-1', 'u-demo',  1, 1250),
('lb-2', 'u-user2', 2, 800),
('lb-3', 'u-user3', 3, 450);

-- Achievements mẫu
INSERT INTO user_achievements (user_id, badge_id) VALUES
('u-demo', 1),
('u-demo', 2),
('u-user2', 1);
