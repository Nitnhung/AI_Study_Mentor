package com.brightpath.aimentor.config;
import com.brightpath.aimentor.entity.*;
import com.brightpath.aimentor.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);
    private final UserRepository userRepo; private final SubjectRepository subjectRepo;
    private final NotificationRepository notifRepo; private final LeaderboardRepository leaderRepo;
    private final PasswordEncoder encoder;

    public DataSeeder(UserRepository ur, SubjectRepository sr, NotificationRepository nr, LeaderboardRepository lr, PasswordEncoder enc) {
        this.userRepo=ur; this.subjectRepo=sr; this.notifRepo=nr; this.leaderRepo=lr; this.encoder=enc;
    }

    @Override public void run(String... args) {
        if (userRepo.existsByEmail("admin@gmail.com")) { log.info("Dữ liệu mẫu đã tồn tại."); return; }
        log.info("Tạo dữ liệu mẫu...");
        subjectRepo.save(new Subject("s-math","Toán","Toán học các cấp"));
        subjectRepo.save(new Subject("s-eng","Tiếng Anh","Ngữ pháp, từ vựng"));
        subjectRepo.save(new Subject("s-phys","Vật Lý","Cơ, điện, quang"));
        subjectRepo.save(new Subject("s-chem","Hoá Học","Vô cơ, hữu cơ"));
        subjectRepo.save(new Subject("s-it","CNTT","Lập trình, mạng"));
        subjectRepo.save(new Subject("s-hist","Lịch Sử","VN và thế giới"));
        userRepo.save(new User("u-demo","admin@gmail.com",encoder.encode("123456"),"high_school","step_by_step","free",1250));
        notifRepo.save(new Notification("n-1","u-demo","Bạn đạt 1000 XP","Motivation"));
        notifRepo.save(new Notification("n-2","u-demo","Quiz mới đã sẵn sàng","Alert"));
        notifRepo.save(new Notification("n-3","u-demo","Bạn chưa học hôm nay","Reminder"));
        leaderRepo.save(new Leaderboard("lb-1","u-demo",1,1250));
        log.info("Done! Demo: admin@gmail.com / 123456");
    }
}
