package com.brightpath.aimentor.service;

import com.brightpath.aimentor.dto.AiAnswerResponse;
import com.brightpath.aimentor.dto.AskQuestionRequest;
import com.brightpath.aimentor.entity.*;
import com.brightpath.aimentor.repository.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

@Service
public class QuestionService {
    private static final Logger log = LoggerFactory.getLogger(QuestionService.class);
    private final QuestionRepository questionRepo;
    private final AiAnswerRepository answerRepo;
    private final UserRepository userRepo;
    private final GeminiService gemini;
    private final ActivityLogService logService;
    private final ObjectMapper mapper = new ObjectMapper();

    public QuestionService(QuestionRepository qr, AiAnswerRepository ar, UserRepository ur,
                           GeminiService gs, ActivityLogService ls) {
        this.questionRepo=qr; this.answerRepo=ar; this.userRepo=ur; this.gemini=gs; this.logService=ls;
    }

    public AiAnswerResponse askQuestion(String userId, AskQuestionRequest req) {
        User user = userRepo.findById(userId).orElseThrow(() -> new RuntimeException("User không tồn tại."));
        String text = req.getContentText() != null ? req.getContentText().trim() : "";
        String hash = hashQuestion(text);

        if (!text.isEmpty() && req.getImageBase64() == null) {
            Optional<Question> cached = questionRepo.findByQuestionHash(hash);
            if (cached.isPresent()) {
                Optional<AiAnswer> ca = answerRepo.findByQuestionId(cached.get().getQuestionId());
                if (ca.isPresent()) {
                    log.info("Cache HIT hash={}", hash.substring(0, 16));
                    return parseAnswer(cached.get().getQuestionId(), ca.get().getContentData(), true, 0, "cache");
                }
            }
        }

        Question q = new Question();
        q.setQuestionId(UUID.randomUUID().toString()); q.setUserId(userId);
        q.setQuestionText(text.isEmpty() ? "(ảnh)" : text); q.setQuestionHash(hash);
        q.setImageUrl(req.getImageBase64() != null ? "base64" : null); q.setStatus("Pending");
        questionRepo.save(q);

        String sys = gemini.buildSystemPrompt(user.getEducationLevel(), user.getPreferredStyle());
        String raw;
        try {
            if (req.getImageBase64() != null && !req.getImageBase64().isBlank()) {
                String up = text.isEmpty() ? "Đọc đề bài trong ảnh và giải đáp." : "Câu hỏi (kèm ảnh):\n" + text;
                raw = gemini.generateWithImage(sys, up, req.getImageBase64(),
                        req.getImageMimeType() != null ? req.getImageMimeType() : "image/jpeg");
            } else {
                raw = gemini.generate(sys, "Câu hỏi của học sinh:\n" + text);
            }
        } catch (Exception e) {
            q.setStatus("Failed"); questionRepo.save(q);
            throw new RuntimeException("Lỗi AI: " + e.getMessage());
        }

        q.setStatus("Resolved"); questionRepo.save(q);
        AiAnswer ans = new AiAnswer();
        ans.setAnswerId(UUID.randomUUID().toString()); ans.setQuestionId(q.getQuestionId());
        ans.setContentData(raw); ans.setIsCachedResponse(false);
        ans.setApiTokensUsed(raw.length() / 4); ans.setAiModelVersion("gemini-2.0-flash");
        answerRepo.save(ans);

        logService.logActivity(userId, "Asked_Question");
        user.setXpPoints(user.getXpPoints() + 10); userRepo.save(user);
        return parseAnswer(q.getQuestionId(), raw, false, ans.getApiTokensUsed(), ans.getAiModelVersion());
    }

    public List<Map<String, Object>> getHistory(String userId) {
        List<Map<String, Object>> result = new ArrayList<>();
        for (Question q : questionRepo.findByUserIdOrderByCreatedAtDesc(userId)) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("questionId", q.getQuestionId()); item.put("questionText", q.getQuestionText());
            item.put("status", q.getStatus()); item.put("createdAt", q.getCreatedAt().toString());
            answerRepo.findByQuestionId(q.getQuestionId()).ifPresent(a -> {
                try { JsonNode n = mapper.readTree(a.getContentData());
                    item.put("directAnswer", n.path("direct_answer").asText(""));
                    item.put("subject", n.path("subject").asText(""));
                } catch (Exception ignored) {}
            });
            result.add(item);
        } return result;
    }

    private AiAnswerResponse parseAnswer(String qId, String json, boolean cached, int tokens, String model) {
        AiAnswerResponse r = new AiAnswerResponse();
        r.setQuestionId(qId); r.setCachedResponse(cached); r.setTokensUsed(tokens); r.setModel(model);
        try {
            JsonNode n = mapper.readTree(json);
            r.setSubject(n.path("subject").asText("other"));
            r.setDifficulty(n.path("difficulty").asText("basic"));
            r.setDirectAnswer(n.path("direct_answer").asText(""));
            r.setExplanation(n.path("explanation").asText(""));
            r.setSteps(toList(n.path("steps")));
            r.setFormulasOrConcepts(toList(n.path("formulas_or_concepts")));
            r.setSimplifiedExplanation(n.path("simplified_explanation").asText(""));
            r.setAlternativeApproaches(toList(n.path("alternative_approaches")));
            r.setKeyConceptsSummary(toList(n.path("key_concepts_summary")));
            r.setCommonMistakes(toList(n.path("common_mistakes")));
            r.setFollowUpQuestions(toList(n.path("follow_up_questions")));
        } catch (Exception e) { r.setExplanation(json); }
        return r;
    }

    private List<String> toList(JsonNode a) { List<String> l=new ArrayList<>(); if(a!=null&&a.isArray()) a.forEach(e->l.add(e.asText())); return l; }

    private String hashQuestion(String text) {
        try { byte[] h = MessageDigest.getInstance("SHA-256").digest(text.toLowerCase().replaceAll("\\s+"," ").trim().getBytes(StandardCharsets.UTF_8));
            StringBuilder sb=new StringBuilder(); for(byte b:h) sb.append(String.format("%02x",b)); return sb.toString();
        } catch(Exception e) { return ""; }
    }
}
