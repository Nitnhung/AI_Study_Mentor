package com.brightpath.aimentor.service;

import com.brightpath.aimentor.dto.QuizGenerateRequest;
import com.brightpath.aimentor.entity.*;
import com.brightpath.aimentor.repository.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class QuizService {
    private static final Logger log = LoggerFactory.getLogger(QuizService.class);
    private final QuizRepository quizRepo;
    private final QuizQuestionRepository qqRepo;
    private final UserRepository userRepo;
    private final GeminiService gemini;
    private final ActivityLogService logService;
    private final ObjectMapper mapper = new ObjectMapper();

    public QuizService(QuizRepository qr, QuizQuestionRepository qqr, UserRepository ur, GeminiService gs, ActivityLogService ls) {
        this.quizRepo=qr; this.qqRepo=qqr; this.userRepo=ur; this.gemini=gs; this.logService=ls;
    }

    public Map<String,Object> generateQuiz(String userId, QuizGenerateRequest req) {
        User user = userRepo.findById(userId).orElseThrow(() -> new RuntimeException("User không tồn tại."));
        String types = req.getQuestionTypes()!=null ? String.join(", ",req.getQuestionTypes()) : "multiple_choice, short_answer, fill_in_blank";
        String raw = gemini.generate(gemini.buildQuizSystemPrompt(user.getEducationLevel()),
                "Tạo "+req.getNumQuestions()+" câu hỏi luyện tập về: \""+req.getTopic()+"\".\nCác dạng: "+types+".");
        String quizId = UUID.randomUUID().toString();
        Quiz quiz = new Quiz(); quiz.setQuizId(quizId); quiz.setUserId(userId); quizRepo.save(quiz);
        List<Map<String,Object>> questions = new ArrayList<>();
        try { JsonNode arr = mapper.readTree(raw).path("questions");
            if (arr.isArray()) for (JsonNode item : arr) {
                String qqId = UUID.randomUUID().toString();
                QuizQuestion qq = new QuizQuestion(); qq.setQqId(qqId); qq.setQuizId(quizId);
                qq.setQuestionType(item.path("question_type").asText("short_answer"));
                qq.setQuestionPayload(mapper.writeValueAsString(item)); qqRepo.save(qq);
                Map<String,Object> m = new LinkedHashMap<>(); m.put("qqId",qqId);
                m.put("questionType",qq.getQuestionType()); m.put("question",item.path("question").asText());
                if(item.has("options")){List<String> o=new ArrayList<>(); item.path("options").forEach(x->o.add(x.asText())); m.put("options",o);}
                questions.add(m);
            }
        } catch(Exception e) { log.error("Quiz parse error: {}",e.getMessage()); }
        logService.logActivity(userId, "Generated_Quiz");
        return Map.of("quizId",quizId,"questions",questions);
    }

    public Map<String,Object> gradeAnswer(String userId, String qqId, String userAnswer) {
        QuizQuestion qq = qqRepo.findById(qqId).orElseThrow(() -> new RuntimeException("Câu hỏi không tồn tại."));
        try { JsonNode p = mapper.readTree(qq.getQuestionPayload());
            String correct = p.path("correct_answer").asText(""); String expl = p.path("explanation").asText("");
            boolean ok = userAnswer.trim().equalsIgnoreCase(correct.trim());
            String fb = ok ? "Chính xác! "+expl : "Chưa đúng. Đáp án: "+correct+". "+expl;
            qq.setUserAnswer(userAnswer); qq.setIsCorrect(ok); qq.setInstantFeedback(fb); qqRepo.save(qq);
            if(ok) { User u=userRepo.findById(userId).orElse(null); if(u!=null){u.setXpPoints(u.getXpPoints()+5);userRepo.save(u);} }
            return Map.of("isCorrect",ok,"instantFeedback",fb);
        } catch(Exception e) { throw new RuntimeException("Lỗi chấm: "+e.getMessage()); }
    }
}
