package com.brightpath.aimentor.repository;

import com.brightpath.aimentor.entity.Question;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface QuestionRepository extends JpaRepository<Question, String> {
    List<Question> findByUserIdOrderByCreatedAtDesc(String userId);
    Optional<Question> findByQuestionHash(String hash);
}
